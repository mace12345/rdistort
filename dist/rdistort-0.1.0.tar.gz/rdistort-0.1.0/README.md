see Test_rdistort on how to use the code
